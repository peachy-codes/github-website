---
author: Faculty Member
role: Professor
org: University of San Francisco
date: 2025-05-01
quote: Georgia communicates complex ML ideas clearly and collaborates thoughtfully—strong technical work with real-world impact.
source: letter
---
