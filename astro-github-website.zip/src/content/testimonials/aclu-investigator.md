---
author: Senior Investigator
role: Lead Investigator
org: ACLU Northern California
date: 2025-05-01
quote: Georgia quickly built practical ML tools that improved our document reviews and helped us act faster, while protecting sensitive data.
source: letter
---
